﻿namespace CustomExceptions
{
    public class ReportException(string message) : BusinessLogicException(message);
}
