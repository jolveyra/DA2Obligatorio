﻿namespace LogicInterfaces
{
    public interface IImportBuildingLogic
    {
        void ImportBuildings(string dllName, string fileName, Guid userId);
    }
}
