﻿namespace WebModels.ConstructorCompanyAdministratorModels
{
    public class UpdateConstructorCompanyAdministratorRequestModel
    {
        public Guid ConstructorCompanyId { get; set; }
    }
}