﻿namespace WebModels.InvitationModels
{
    public class UpdateInvitationRequestModel
    {
        public bool? IsAccepted { get; set; }
    }
}
