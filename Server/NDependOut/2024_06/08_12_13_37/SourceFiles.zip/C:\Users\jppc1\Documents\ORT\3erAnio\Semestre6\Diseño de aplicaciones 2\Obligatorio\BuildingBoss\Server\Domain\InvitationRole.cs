﻿namespace Domain
{
    public enum InvitationRole
    {
        ConstructorCompanyAdmin,
        Manager,
    }
}
