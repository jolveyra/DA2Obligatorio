﻿using Domain;

namespace LogicInterfaces
{
    public interface ILoginLogic
    {
        public UserLogged Login(User user);
    }
}
