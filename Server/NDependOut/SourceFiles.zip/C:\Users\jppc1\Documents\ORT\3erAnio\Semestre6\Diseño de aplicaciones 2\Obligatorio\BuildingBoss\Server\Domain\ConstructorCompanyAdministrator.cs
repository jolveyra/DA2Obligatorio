﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class ConstructorCompanyAdministrator: User
    {
        public Guid ConstructorCompanyId { get; set; }
        public ConstructorCompany ConstructorCompany { get; set; } = new ConstructorCompany() { Name = "" };
    }
}
