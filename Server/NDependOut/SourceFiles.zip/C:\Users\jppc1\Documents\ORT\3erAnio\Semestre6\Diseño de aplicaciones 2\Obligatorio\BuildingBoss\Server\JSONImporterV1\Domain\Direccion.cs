﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSONImporterV1.Domain
{
    public class Direccion
    {
        public string Calle_principal { get; set; }
        public int Numero_puerta { get; set; }
        public string Calle_secundaria { get; set; }
    }
}
