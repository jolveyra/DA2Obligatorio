﻿namespace WebModels.BuildingImportModels
{
    public class BuildingImportRequestModel
    {
        public string DllName { get; set; }
        public string FileName { get; set; }
    }
}
