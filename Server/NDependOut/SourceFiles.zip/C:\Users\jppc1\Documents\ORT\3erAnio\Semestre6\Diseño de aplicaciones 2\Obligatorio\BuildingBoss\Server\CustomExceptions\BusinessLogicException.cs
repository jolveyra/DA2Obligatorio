﻿namespace CustomExceptions
{
    public abstract class BusinessLogicException(string message) : Exception(message);
}
