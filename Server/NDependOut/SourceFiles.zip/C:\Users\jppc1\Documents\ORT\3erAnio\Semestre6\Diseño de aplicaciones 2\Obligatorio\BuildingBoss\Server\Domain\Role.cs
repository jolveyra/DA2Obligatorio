﻿
namespace Domain
{
    public enum Role
    {
        Administrator,
        Manager,
        MaintenanceEmployee,
        ConstructorCompanyAdmin
    }
}
