﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSONImporterV1.Domain
{
    public class Gps
    {
        public double Latitud { get; set; }
        public double Longitud { get; set; }
    }
}
