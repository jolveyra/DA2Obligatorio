﻿namespace WebModels.ImportBuildingModels
{
    public class ImportBuildingRequestModel
    {
        public string DllName { get; set; }
        public string FileName { get; set; }
    }
}
