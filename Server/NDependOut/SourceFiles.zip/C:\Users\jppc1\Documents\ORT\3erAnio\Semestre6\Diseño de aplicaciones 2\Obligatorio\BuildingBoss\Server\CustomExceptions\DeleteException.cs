﻿namespace CustomExceptions
{
    public class DeleteException() : Exception();
}
